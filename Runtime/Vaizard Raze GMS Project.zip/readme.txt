﻿TCP ports for hosting: 17651
UDP ports for hosting: 17651
UDP ports for joining: 17652-1669


(Standard controls)
Left+Right arrows = Move
Up+Down arrows = Look up/down
Z = Jump
X = Primary Fire
C = Secondary Fire
A = Ability 1
S = Ability 2
D = Ability 3

Space = Swap Weapons





RED = 255
GREEN = 32768
ORANGE = 4235519
BLUE = 16711680
LIME = 65280
BLACK = 0
YELLOW = 65535
PURPLE = 8388736
WHITE = 16777215
MAROON/BROWN = 128
TEAL = 8421376